const { ipcRenderer } = require('electron')

document.getElementById('todoForm').addEventListener('submit', (evt) => {
  
    // prevent default refresh functionality of forms
  evt.preventDefault()

  const input = evt.target[0]

  ipcRenderer.send('add-todo', input.value)

  input.value = ''
})

