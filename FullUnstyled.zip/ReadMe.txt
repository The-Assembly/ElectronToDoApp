To execute
1 npm install (to install dependencies)
2 npm start