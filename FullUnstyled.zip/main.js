console.log("write here");

const { app, BrowserWindow, ipcMain } = require('electron');

const path = require("path");
const Window = require("./Window")
const DataStore = require("./DataStore")

require('electron-reload')(__dirname) 

const todosData = new DataStore({ name: 'Todos Main' })

function main()
{
  // todosData
  //   .addTodo('Take Out The Trash')
  //   .addTodo('Do The Laundry')

    let mainWindow = new Window({
        file: path.join('web', 'index.html')
    })

    mainWindow.once('show', () => {
      mainWindow.webContents.send('todos', todosData.todos)
    })
  
    let addTodoWin

    ipcMain.on('add-todo-window', () => {
        if (!addTodoWin) {

            addTodoWin = new Window({
            file: path.join('web', 'add.html'),
            width: 400,
            height: 400,
            parent: mainWindow
          })
    
          addTodoWin.on('closed', () => {
            addTodoWin = null
          })
        }
      })    
    
    ipcMain.on('add-todo', (event, todo) => {
      const updatedTodos = todosData.addTodo(todo).todos

      mainWindow.send('todos', updatedTodos)
    })

    ipcMain.on('delete-todo', (event, todo) => {
      const updatedTodos = todosData.deleteTodo(todo).todos
  
      mainWindow.send('todos', updatedTodos)
    })  
}

app.on('ready', main)

app.on('window-all-closed', function () {
  app.quit()
})
